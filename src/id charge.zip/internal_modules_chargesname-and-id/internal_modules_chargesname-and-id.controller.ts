/* eslint-disable prettier/prettier */
import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { InternalModulesChargesnameAndIdService } from './internal_modules_chargesname-and-id.service';

@Controller('internal-modules-chargesname-and-id')
export class InternalModulesChargesnameAndIdController {
  constructor(private readonly internalModulesChargesnameAndIdService: InternalModulesChargesnameAndIdService) {}

  @Get(':id')
  findOne(@Param('id') id:number) {
    return this.internalModulesChargesnameAndIdService.findall(id);
  }

  @Get('charges/:id')
  find(@Param('id') id:number) {
    return this.internalModulesChargesnameAndIdService.findcharges(id);
  }
}
