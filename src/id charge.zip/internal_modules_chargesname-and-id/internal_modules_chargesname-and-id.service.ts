import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection } from 'typeorm';

@Injectable()
export class InternalModulesChargesnameAndIdService {
  constructor(@InjectConnection() private connection: Connection)
  {}

  async findall(charge_category_id:number) {
    const charges = await this.connection.query(`select charges.id,charges.name from charges where charge_category_id = ?`,[charge_category_id]);
    console.log(charges);
    
    return charges;
  }

  async findcharges(standard_charge:number) {
    const charges_amount = await this.connection.query(`select charges.standard_charge from charges where charges.id = ?`,[standard_charge])
    console.log(charges_amount);
  
    return charges_amount;
    
   }


}
